export const datasetList =
[
   {'name' : 'Dataset 1', 'text': 'Last executed on - Jan 2014'},
   {'name' : 'Dataset 2', 'text': 'Last executed on - Jan 2014'},
   {'name' : 'Dataset 3', 'text': 'Last executed on - Jan 2014'},
   {'name' : 'Dataset 4', 'text': 'Last executed on - Jan 2014'},
   {'name' : 'Dataset 5', 'text': 'Last executed on - Jan 2014'},
   {'name' : 'Dataset 6', 'text': 'Last executed on - Jan 2014'},
   {'name' : 'Dataset 7', 'text': 'Last executed on - Jan 2014'},
   {'name' : 'Dataset 8', 'text': 'Last executed on - Jan 2014'},
   {'name' : 'Dataset 9', 'text': 'Last executed on - Jan 2014'},
   {'name' : 'Dataset 10', 'text': 'Last executed on - Jan 2014'}
    
]