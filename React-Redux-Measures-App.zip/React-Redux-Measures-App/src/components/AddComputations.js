import React, { Component } from 'react';

export default class AddComputations extends Component {
    render() {
        return (
              <div className='add-computation-div'>
                   <div className='tab-number'>
                        <div>3</div>
                    </div>
                     <div className='tab-label'>Add Computations</div>
                </div>
        );
    }
}