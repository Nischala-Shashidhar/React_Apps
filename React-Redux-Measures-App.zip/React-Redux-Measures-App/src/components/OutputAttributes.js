import React, { Component } from 'react';

class OutputAttributes extends Component {
    render() {
        return (
          <div className='output-attributes-div'>
                   <div className='tab-number'>
                        <div>4</div>
                    </div>
                     <div className='tab-label'>Output Attributes</div>
         </div>
        );
    }
}

export default OutputAttributes;