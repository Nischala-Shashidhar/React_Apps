import React, { Component } from 'react';

class Summary extends Component {
    render() {
        return (
           <div className='summary-div'>
                   <div className='tab-number'>
                        <div>5</div>
                    </div>
                     <div className='tab-label'>Summary</div>
           </div>
        );
    }
}

export default Summary;